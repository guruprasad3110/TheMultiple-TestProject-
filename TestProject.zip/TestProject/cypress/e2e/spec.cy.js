/**** the below test(s) search for the phrases with localised settings using domain ****/
describe('Search with specific words', () => {
 
// Search for the Phrase "Malta" with the localised Malta domain (.mt) to make sure results are localised 
  it('search for malta', () => {
    cy.visit('https://google.com.mt')
    cy.get('textarea[role="combobox"]')
    .should('be.visible')
    .type('Malta')  //search for the word Malta
    cy.xpath('//div[@role="option" and @aria-label="malta" and @aria-description="Country in Europe"]')  //select the appropriate one from the list
    .click()
    cy.xpath('//span[contains(text(),"Malta is an archipelago in the central Mediterranean between Sicily and the North African coast")]')
    .should('exist') //Verifying the proper search results related to malta is displayed 
    
   })

   // Search for the Phrase "Valletta" with the localised Malta domain (.mt) to make sure results are localised
   it('search for Valletta', () => {
    cy.visit('https://google.com.mt')
    cy.get('textarea[role="combobox"]')
    .should('be.visible')
    .type('Valletta')
//Select the appropriate search result for Valletta
    cy.xpath('//div[@role="option" and @aria-label="valletta" and @aria-description="Capital of Malta"]') 
    .click()
    cy.xpath('//span[contains(text(),"Valletta (or Il-Belt) is the tiny capital of the Mediterranean island nation of Malta")]')
    .should('exist')
   })

   //Searching for the Word "The Multiple.com using Enter Key in the search bar"

   it('search for The Multiple', () => {
    cy.visit('https://google.com.mt')
    cy.get('textarea[role="combobox"]')
    .should('be.visible')
    .type('The Multiple.com{enter}')
//Search and click Enter using Enter Key 

//verify the Link is displayed

cy.xpath('//h3[text()="The Multiple Group | Your Go To iGaming Provider in 2024"]')
    .should('be.visible')
})


//To perform Testing with Local Language we can include the property of changing language in the Framework by using coed below 
it('Test with Regional Language', () => {
  cy.visit('https://google.com/', {
  onBeforeLoad(win) {
  Object.defineProperty(win.navigator, 'language', { value: 'mt-MT' });
  Object.defineProperty(win.navigator, 'languages', { value: ['mt'] });
  Object.defineProperty(win.navigator, 'accept_languages', { value: ['mt'] });
  },
  headers: {
  'Accept-Language': 'mt',
  },
});  
  });
   })

