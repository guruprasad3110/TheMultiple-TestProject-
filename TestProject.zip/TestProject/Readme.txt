******************** Test Project ****************************************


1) Contains the Tests (First 3 tests) which searches for the Words "Malta" , " Valletta" , "The Multiple.com" using the localized domain (google.com.mt)

  


2) Contains a Test to demonstrate how localization can be achieved at the Framework Level by changing the Langauge settings of the browser 


Project contains :

1) Package.json ---> Contains Project name along with the Scripts 

2) Node Modules --> All the cypress modules , node modules are present here

3) Spec.cy.js ---> contains the Test cases 

4) e2e.js  ---> Contains the required libraries to run Tests



********************************* Other Files in the Project Folder ********************************

1) How to Install Cypress and Run Tests. docx --> Illustrate how to install the cypress and cypress configuration 

2) Test Case description and Test Reults.docx --> Results of the tests executed 